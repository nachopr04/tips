import json
import boto3
import joblib
import tarfile
import os
import numpy as np

# Ruta local donde se descargará y extraerá el modelo
MODEL_LOCAL_PATH = '/tmp/model.joblib'
MODEL_TAR_PATH = '/tmp/model.tar.gz'

def download_model_from_s3(bucket, key, dest_path):
    s3 = boto3.client('s3')
    try:
        s3.download_file(bucket, key, dest_path)
        print(f"Modelo descargado correctamente desde s3://{bucket}/{key}")
    except Exception as e:
        print(f"Error al descargar el modelo: {e}")
        raise e

def extract_model(tar_path, extract_to):
    try:
        with tarfile.open(tar_path, "r:gz") as tar:
            tar.extractall(path=extract_to)
        print(f"Modelo extraído en {extract_to}")
    except Exception as e:
        print(f"Error al extraer el modelo: {e}")
        raise e

def load_model(model_path):
    try:
        model = joblib.load(model_path)
        print("Modelo cargado exitosamente")
        return model
    except Exception as e:
        print(f"Error al cargar el modelo: {e}")
        raise e

# Descargar y cargar el modelo al inicio de la función Lambda
download_model_from_s3('predicciontips', 'model/model.tar.gz', MODEL_TAR_PATH)
extract_model(MODEL_TAR_PATH, '/tmp')
model = load_model(MODEL_LOCAL_PATH)

def lambda_handler(event, context):
    try:
        # Obtener datos de entrada del evento
        input_data = json.loads(event['body'])
        print(f"Datos de entrada: {input_data}")
        
        # Realizar la predicción
        input_array = np.array(input_data['data']).reshape(1, -1)  # Asegurarse de que los datos estén en el formato correcto
        prediction = model.predict(input_array)
        
        # Preparar la respuesta
        result = {
            'statusCode': 200,
            'body': json.dumps({
                'prediction': prediction.tolist()
            })
        }
        
        return result
    except Exception as e:
        print(f"Error al realizar la predicción: {e}")
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }
